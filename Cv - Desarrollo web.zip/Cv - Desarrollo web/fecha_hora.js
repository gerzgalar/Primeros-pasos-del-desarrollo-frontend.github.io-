<button type="button"
onclick="document.getElementById('demo').innerHTML = Date()">
Hacer click para saber el día y hora.</button>